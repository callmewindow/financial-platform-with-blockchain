import provider.BlockChainServiceImpl;
import utils.exceptions.ReadFailureException;

public class Test {
    public static void main(String[] args) {
        BlockChainServiceImpl blockChainService = GetFabricManager.getBlockChainService();
        /*try {
            System.out.println(blockChainService.queryFinancingApply(500));
        } catch (ReadFailureException e) {
            e.printStackTrace();
        }*/
        /*try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        try {
            blockChainService.invokeContract(5000, "Contract information");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            blockChainService.invokeUserInformation("User A", "A's information");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            blockChainService.invokeFinancingApply(516, "A's information");
        } catch (Exception e) {
            e.printStackTrace();
        }
        //System.out.println(blockChainService.InsertTransaction("1000", 100, 12, 34, 23, "2018", true, 23.33));
        //System.out.println((blockChainService.QueryTransaction("1000")));
    }
}
