package utils.exceptions;

public class ReadFailureException extends Exception {
}
