package utils.exceptions;

public class WriteFailureException extends Exception {
}
