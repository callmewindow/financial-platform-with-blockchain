import provider.BlockChainServiceImpl;

public class Main {
    public static void main(String[] args) {
        BlockChainServiceImpl blockChainService = GetFabricManager.getBlockChainService();
        /*try {
            blockChainService.invokeFinancingApply(500000, "hello");
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        // 查询实名信息
        /*try {
            System.out.println(blockChainService.queryUserInformation("234@234.COM"));
            //Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        // 查询转账
        try {
            System.out.println(blockChainService.queryTransaction(180));
            //Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 查询融资申请
        /*try {
            System.out.println(blockChainService.queryFinancingApply(22));
            //Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        /*try {
            blockChainService.invokeContract(500001, "mycontract");
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            System.out.println(blockChainService.queryContract(500001));
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }
}
