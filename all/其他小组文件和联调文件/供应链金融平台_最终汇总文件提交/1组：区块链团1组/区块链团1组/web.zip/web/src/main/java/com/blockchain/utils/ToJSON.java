package com.blockchain.utils;

import org.json.JSONObject;

public interface ToJSON
{
	JSONObject toJSON();
}
