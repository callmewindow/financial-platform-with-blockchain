package com.blockchain.model;

import com.blockchain.utils.ToJSON;

abstract public class Profile implements ToJSON {

}
